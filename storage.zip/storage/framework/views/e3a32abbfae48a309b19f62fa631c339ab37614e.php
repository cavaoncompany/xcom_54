<p>Hi, This is <?php echo e($data['firstname']); ?> <?php echo e($data['lastname']); ?></p>

<p>I have some query like <?php echo e($data['message']); ?></p>