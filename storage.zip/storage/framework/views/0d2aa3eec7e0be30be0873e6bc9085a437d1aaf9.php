<?php $__env->startSection('page_title', __('voyager::generic.viewing').' '.$dataType->display_name_plural); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="container-fluid">
        <h1 class="page-title">
            <i class="<?php echo e($dataType->icon); ?>"></i> Xcom Contents
        </h1>
        
    
        <?php $__currentLoopData = Voyager::actions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(method_exists($action, 'massAction')): ?>
                <?php echo $__env->make('voyager::bread.partials.actions', ['action' => $action, 'data' => null], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('voyager::multilingual.language-selector', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<style>

.tab-content .card{
    padding:15px;
}
.tab-content .card-header{
    color: black;
    font-weight: bold;
    padding-bottom: 15px;
}

.tab-content .itemStyle{
    margin:20px 0;
}
.tab-content{
    margin-left:-10px;
}
.voyager{
    background-color:#f9f9f9 !important;
}
@media  only screen and (min-width: 500px) {
.xcomnavs{
    padding:10px; 
    margin-left:70px !important;
}}
@media  only screen and (max-width: 500px) {
    .xcomnavs{
        margin-left:0;
    }
}
.itemStyle h5{
    color:black;
}
</style>

<?php $__env->startSection('content'); ?>
    <div class="page-content browse container-fluid">
        <?php echo $__env->make('voyager::alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
  <br>
  <!-- Nav pills -->
  <ul class="nav nav-pills xcomnavs" role="tablist" id="tabMenu">
    <li class="nav-item active">
      <a class="nav-link " data-toggle="pill" href="#home">GENERAL CONTENTS</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="pill" href="#service">SERVICE</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="pill" href="#about">ABOUT</a>
    </li>
  </ul>
 

                          
  <?php  
        define('info', "XCOM INFORMATION");
        define('service', "SERVICE");
        define('about', "ABOUT");
        $headerdata = array();
        $herodata = array();
        $servicetitledata = array();
        $aboutdata = array();
        $footerdata = array();
        $firstservicedata = array();
        $secondservicedata = array();
        $thirdservicedata = array();
        $forthservicedata = array();
        $emaildata = array();
                         
     foreach($dataTypeContent as $data){
        if ($data->part =="Header"){
            array_push($headerdata, $data); 
        }
        if ($data->part =="servicetitle"){
            array_push($servicetitledata, $data); 
        }
        if ($data->part =="01"){
            array_push($firstservicedata, $data); 
        }
        if ($data->part =="02"){
            array_push($secondservicedata, $data); 
        }
        if ($data->part =="03"){
            array_push($thirdservicedata, $data); 
        }
        if ($data->part =="04"){
            array_push($forthservicedata, $data); 
        }
        if ($data->part =="about"){
            array_push($aboutdata, $data);
        }     
        if ($data->part =="HeroBanner"){
            array_push($herodata, $data);
        }
        if ($data->part =="Footer"){
            array_push($footerdata, $data);
        }   
        if ($data->part == "toemail"){
            array_push($emaildata, $data);
        }        
     }
   ?>   
  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <div class="row">
        <div class="col-md-12 card">
            <h4 class="col-md-12 card-header">Header</h4>
            <?php $id=array() ?>
            <?php $__currentLoopData = $headerdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 itemStyle">
                <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                <p class="valueStyle"> <?php echo e($data->content); ?> </p> 
            </div>
            <?php array_push($id, $data->id); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 text-left">
                <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
            </div>
        </div>
        <div class="col-md-12 card">
            <h4 class="col-md-12 card-header">Hero Banner</h4>
            <?php $id=array() ?>
            <?php $__currentLoopData = $herodata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 itemStyle">
                <h5 style="color:#000"><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                <p class="valueStyle"> <?php echo e($data->content); ?> </p>  
            </div>
            <?php array_push($id, $data->id); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 text-left">
                <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
            </div>
        </div>

        <div class="col-md-12 card">
            <h4 class="col-md-12 card-header">Footer</h4>
            <?php $id=array() ?>
            <?php $__currentLoopData = $footerdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 itemStyle">
                <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                <p class="valueStyle"> <?php echo e($data->content); ?> </p>
            </div>
            <?php array_push($id, $data->id); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-left col-md-12">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
            </div>
        </div>

        <div class="col-md-12 card">
            <h4 class="col-md-12 card-header">To Email</h4>
            <?php $id=array() ?>
            <?php $__currentLoopData = $emaildata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 itemStyle">
                <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                <p class="valueStyle"> <?php echo e($data->content); ?> </p>
            </div>
            <?php array_push($id, $data->id); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-left col-md-12">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
            </div>
        </div>
      </div>
    </div>
    <div id="service" class="container tab-pane fade"><br>
        <div class="row">

           <?php $__currentLoopData = $servicetitledata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-12 card">
                <h4 class="col-md-12 card-header"><?php echo e($data->part); ?></h4>
                <?php $id=array() ?>
                <div class="col-md-6 itemStyle">
                    <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                    <p class="valueStyle"> <?php echo e($data->content); ?> </p>
                </div>
                <?php array_push($id, $data->id); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 text-left">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
                </div>
            </div>
            
            <div class="col-md-12 card">
                <h4 class="col-md-12 card-header">01</h4>
                <br>
                <?php $id=array() ?>
                <?php $__currentLoopData = $firstservicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 itemStyle">
                    <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                    <p class="valueStyle" style="min-height:88px;"> <?php echo e($data->content); ?> </p>
                </div>
                <?php array_push($id, $data->id); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 text-left">
                    <a href="http://staging.xcomit.com.au/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
                </div>
            </div>

            <div class="col-md-12 card">
                <h4 class="col-md-12 card-header">02</h4>
                <br>
                <?php $id=array() ?>
                <?php $__currentLoopData = $secondservicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 itemStyle">
                    <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                    <p class="valueStyle" style="min-height:88px;"> <?php echo e($data->content); ?> </p>
                </div>
                <?php array_push($id, $data->id); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 text-left">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
                </div>
            </div>

            <div class="col-md-12 card">
                <h4 class="col-md-12 card-header">03</h4>
                <br>
                <?php $id=array() ?>
                <?php $__currentLoopData = $thirdservicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 itemStyle">
                    <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                    <p class="valueStyle" style="min-height:88px;"> <?php echo e($data->content); ?> </p>
                </div>
                <?php array_push($id, $data->id); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 text-left">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
                </div>
            </div>

            <div class="col-md-12 card">
                <h4 class="col-md-12 card-header">04</h4>
                <br>
                <?php $id=array() ?>
                <?php $__currentLoopData = $forthservicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 itemStyle">
                    <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                    <p class="valueStyle" style="min-height:88px;"> <?php echo e($data->content); ?> </p>
                </div>
                <?php array_push($id, $data->id); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 text-left">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
                </div>
            </div>
        </div>
    </div>
    <div id="about" class="container tab-pane fade">
        <div class="row">
            <div class="col-md-12 card">
                <h4 class="col-md-12 card-header">About</h4>
                <br>
                <?php $id=array() ?>
                <?php $__currentLoopData = $aboutdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 itemStyle">
                    <h5><?php echo e(preg_replace('/(?<!\ )[A-Z]/', ' $0', $data->category)); ?></h5>
                    <p class="valueStyle" style="min-height:154px;"> <?php echo e($data->content); ?> </p>
                </div>
                <?php array_push($id, $data->id); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 text-left">
                    <a href="http://staging.xcomit.com.au/admin/xcomcontent/<?php echo e(implode("|",$id)); ?>/edit" class="card-link btn btn-warning" type="button" >Edit</a>
                </div>
            </div>
        </div>
    </div>
  </div>
            
    </div><!-- /.modal -->
     
    <div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo e(__('voyager::generic.close')); ?>"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="voyager-trash"></i> <?php echo e(__('voyager::generic.delete_question')); ?> <?php echo e(strtolower($dataType->display_name_singular)); ?>?</h4>
                </div>
                <div class="modal-footer">
                    <form action="#" id="delete_form" method="POST">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <input type="submit" class="btn btn-danger pull-right delete-confirm" style="margin-top:15px;" value="<?php echo e(__('voyager::generic.delete_confirm')); ?>">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal"><?php echo e(__('voyager::generic.cancel')); ?></button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
    <!-- DataTables -->
    <?php if(!$dataType->server_side && config('dashboard.data_tables.responsive')): ?>
        <script src="<?php echo e(voyager_asset('lib/js/dataTables.responsive.min.js')); ?>"></script>
    <?php endif; ?>
    <script>
         $(document).ready(function () {
            $('#tabMenu a[href="#<?php echo e(old('tab')); ?>"]').tab('show')
        });
        $(document).ready(function () {
            <?php if(!$dataType->server_side): ?>
                var table = $('#dataTable').DataTable(<?php echo json_encode(
                    array_merge([
                        "order" => $orderColumn,
                        "language" => __('voyager::datatable'),
                        "columnDefs" => [['targets' => -1, 'searchable' =>  false, 'orderable' => false]],
                    ],
                    config('voyager.dashboard.data_tables', []))
                , true); ?>);
            <?php else: ?>
                $('#search-input select').select2({
                    minimumResultsForSearch: Infinity
                });
            <?php endif; ?>

            <?php if($isModelTranslatable): ?>
                $('.side-body').multilingual();
                //Reinitialise the multilingual features when they change tab
                $('#dataTable').on('draw.dt', function(){
                    $('.side-body').data('multilingual').init();
                })
            <?php endif; ?>
            $('.select_all').on('click', function(e) {
                $('input[name="row_id"]').prop('checked', $(this).prop('checked'));
            });
        });


        var deleteFormAction;
        $('.delete').on('click', function (e) {
            $('#delete_form')[0].action = '<?php echo e(route('voyager.'.$dataType->slug.'.destroy', ['id' => '__id'])); ?>'.replace('__id', $(this).data('id'));
            $('#delete_modal').modal('show');
        });

        <?php if($usesSoftDeletes): ?>
            <?php 
                $params = [
                    's' => $search->value,
                    'filter' => $search->filter,
                    'key' => $search->key,
                    'order_by' => $orderBy,
                    'sort_order' => $sortOrder,
                ];
             ?>
            $(function() {
                $('#show_soft_deletes').change(function() {
                    if ($(this).prop('checked')) {
                        $('#dataTable').before('<a id="redir" href="<?php echo e((route('voyager.'.$dataType->slug.'.index', array_merge($params, ['showSoftDeleted' => 1]), true))); ?>"></a>');
                    }else{
                        $('#dataTable').before('<a id="redir" href="<?php echo e((route('voyager.'.$dataType->slug.'.index', array_merge($params, ['showSoftDeleted' => 0]), true))); ?>"></a>');
                    }

                    $('#redir')[0].click();
                })
            })
        <?php endif; ?>
        $('input[name="row_id"]').on('change', function () {
            var ids = [];
            $('input[name="row_id"]').each(function() {
                if ($(this).is(':checked')) {
                    ids.push($(this).val());
                }
            });
            $('.selected_ids').val(ids);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>